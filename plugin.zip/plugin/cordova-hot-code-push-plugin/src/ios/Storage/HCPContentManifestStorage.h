//
//  HCPContentManifestStorage.h
//
//  Created by Nikolay Demyankov on 12.08.15.
//

#import "HCPConfigStorageImpl.h"
#import "HCPFilesStructure.h"

//-----修改-----
#import "ZQFileStructure.h"
//-----结束-----

/**
 *  Utility class to save and load content manifest file from the certain folder.
 * 
 *  @see HCPContentManifest
 */
@interface HCPContentManifestStorage : HCPConfigStorageImpl

/**
 *  Object initializer
 *
 *  @param fileStructure plugins file structure
 *
 *  @return instance of the object
 */
- (instancetype)initWithFileStructure:(HCPFilesStructure *)fileStructure;

- (instancetype)initWithZQFileStructure:(ZQFileStructure *)fileStructure;

@end
