var exec = require('cordova/exec');

var AUpdatePlugin = function () {
};

AUpdatePlugin.prototype.errorCallback = function (msg) {
    console.log('Javascript Callback Error: ' + msg)
};

AUpdatePlugin.prototype.callNative = function (name, args, successCallback) {
    exec(successCallback, this.errorCallback, 'AUpdatePlugin', name, args)
};


AUpdatePlugin.prototype.coolMethod = function (arg0, success) {
    // arg0 必须加括号
    this.callNative('coolMethod', [arg0], success)
};

/**
 * 更新微应用
 * @param serverAddress 服务器端地址<http://192.168.40.240:8080/incrementalUpdate/www/chcp.json>
 * @param appName 微应用名称<不能是中文,只能是英文>
 * @param success
 */
AUpdatePlugin.prototype.downloadUpdate = function (serverAddress, appName, success) {
    // arg0 必须加括号
    this.callNative('downloadUpdate', [serverAddress, appName], success)
};

/**
 * 下载微应用
 * @param serverAddress 服务器地址<http://192.168.40.240:8080/anyware/www.zip>
 * @param appName 微应用名称<不能是中文,只能是英文>
 * @param success
 */
AUpdatePlugin.prototype.downloadWwwFolder = function (serverAddress, appName, success) {
    // arg0 必须加括号
    this.callNative('downloadWwwFolder', [serverAddress, appName], success)
};


if (!window.plugins) {
    window.plugins = {}
}

if (!window.plugins.AUpdatePlugin) {
    window.plugins.AUpdatePlugin = new AUpdatePlugin()
}

module.exports = new AUpdatePlugin();
