
/**
 朱志强
 */
#import "ZQUpdateLoaderWorker.h"
#import "HCPContentManifest.h"
#import "HCPApplicationConfig.h"
#import "HCPFileDownloader.h"
#import "HCPConfigFileStorage.h"
#import "HCPUpdateRequest.h"
#import "HCPApplicationConfigStorage.h"
#import "HCPContentManifestStorage.h"
#import "HCPDataDownloader.h"
#import "ZQFileStructure.h"
#import "SSZipArchive.h"

@interface ZQUpdateLoaderWorker ()
{
    NSURL *_configURL;
    ZQFileStructure *fileStructure;
    NSUInteger _nativeInterfaceVersion;
    
    id<HCPConfigFileStorage> _appConfigStorage;
    id<HCPConfigFileStorage> _manifestStorage;
    
    HCPApplicationConfig *_oldAppConfig;
    HCPContentManifest *_oldManifest;
    
    NSDictionary *_requestHeaders;
    
    void (^_complitionBlock)(NSError*);
}

@end

@implementation ZQUpdateLoaderWorker

- (instancetype)initWithRequest:(HCPUpdateRequest *)request appName:(NSString *)appName
{
    self = [super init];
    if (self) {
        _configURL = [request.configURL copy];
        _requestHeaders = [request.requestHeaders copy];
        _nativeInterfaceVersion = request.currentNativeVersion;
        fileStructure = [[ZQFileStructure alloc] initWithAppName:appName webVersion:request.currentWebVersion];
        _appConfigStorage = [[HCPApplicationConfigStorage alloc] initWithZQFileStructure:fileStructure];
        _manifestStorage = [[HCPContentManifestStorage alloc] initWithZQFileStructure:fileStructure];
        [self loadLocalConfigs:nil];
    }
    return self;
}

- (HCPContentManifest*)getContentManifestFromData:(NSData*)data error:(NSError**)error
{
    if (*error) {
        return nil;
    }
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:error];
    if (*error) {
        return nil;
    }
    
    return [HCPContentManifest instanceFromJsonObject:json];
}

//开始更新
- (void)runWithComplitionBlock:(void (^)(NSError *error))updateLoaderComplitionBlock
{
    _complitionBlock = updateLoaderComplitionBlock;
    
    
    HCPDataDownloader *configDownloader = [[HCPDataDownloader alloc] init];
    
    // 下载chcp.json
    [configDownloader downloadDataFromUrl:_configURL requestHeaders:_requestHeaders completionBlock:^(NSData *data, NSError *error) {
        
        if(error) {
            _complitionBlock(error);
        }
        
        HCPApplicationConfig *newAppConfig = [self getApplicationConfigFromData:data error:&error];
        
        // 下载chcp.manifest
        NSURL *manifestFileURL = [newAppConfig.contentConfig.contentURL URLByAppendingPathComponent:@"chcp.manifest"];
        
        [configDownloader downloadDataFromUrl:manifestFileURL requestHeaders:_requestHeaders completionBlock:^(NSData *data, NSError *error) {
            
            if(error) {
                _complitionBlock(error);
            }
            
            HCPContentManifest *newManifest = [self getContentManifestFromData:data error:&error];
            
            // 1.对比
            HCPManifestDiff *manifestDiff = [_oldManifest calculateDifference:newManifest];
            
            // 2.没有新内容，直接返回
            if (manifestDiff.isEmpty) {
                //保存
                [_manifestStorage store:newManifest inFolder:fileStructure.wwwFolder];
                [_appConfigStorage store:newAppConfig inFolder:fileStructure.wwwFolder];
                return;
            }
            
            // 3.复制一份www文件
            if([self copyWWWFolderFromOldToNewWithConfig:newAppConfig]) {
                // 4.删除www(copy)中已经存在的文件
                [self deleteFileInNewWWWFolder:manifestDiff.deletedFiles];
                // 5.创建下载文件夹
                [self createNewReleaseDownloadFolder:fileStructure.downloadFolder];
            }
            
            // if there is anything to load - do that
            NSArray *updatedFiles = manifestDiff.updateFileList;
            if (updatedFiles.count > 0) {
                
                // ...显示文件的下载进度
                
                [self downloadUpdatedFiles:updatedFiles appConfig:newAppConfig manifest:newManifest callback:^(NSError *error) {
                    if(!error) {
                        // ...隐藏下载进度
                    }
                }];
                return;
            }
            
            // otherwise - update holds only files for deletion;
            // just save new configs and notify subscribers about success
            if(fileStructure.lastestWWWFolder) {
                [_appConfigStorage store:newAppConfig inFolder:fileStructure.lastestWWWFolder];
                [_manifestStorage store:newManifest inFolder:fileStructure.lastestWWWFolder];
            }
        }];
    }];
}

#pragma mark Private API

// 下载需要更新的文件
// updatedFiles：需要更新的文件名称集合
// newAppConfig：获取文件的下载地址
// 
- (void)downloadUpdatedFiles:(NSArray *)updatedFiles
                   appConfig:(HCPApplicationConfig *)newAppConfig
                    manifest:(HCPContentManifest *)newManifest
                         callback:(void(^)(NSError *error))callback
{
    // download files
    HCPFileDownloader *downloader = [[HCPFileDownloader alloc] initWithFiles:updatedFiles
                                                                   srcDirURL:newAppConfig.contentConfig.contentURL
                                                                   dstDirURL:fileStructure.downloadFolder
                                                              requestHeaders:_requestHeaders];
    
    [downloader startDownloadWithCompletionBlock:^(NSError * error) {
        NSFileManager *fm = [NSFileManager defaultManager];
        //下载失败
        if (error) {
            // remove new release folder
            NSLog(@"下载增量文件失败：%@",error);
            [fm removeItemAtPath:fileStructure.downloadFolder.path error:nil];
            return;
        } else {
            // 1.在项目的根目录将下载文件压缩
            NSString *updatePath = [fileStructure.baseFolder.path stringByAppendingPathComponent:@"update.zip"];
            // 1.压缩下载的文件
            if([SSZipArchive createZipFileAtPath:updatePath withContentsOfDirectory:fileStructure.downloadFolder.path]) {
                
                // 2.解压下载的文件到新版本目录
                if([SSZipArchive unzipFileAtPath:updatePath toDestination:fileStructure.lastestWWWFolder.path]) {
                    // 4.删除下载的文件
                    if(![self deleteFileWithPath:updatePath]) {
                        NSLog(@"删除下载的压缩文件%@成功",updatePath);
                    }
                    if(![self deleteFileWithPath:fileStructure.downloadFolder.path]) {
                        NSLog(@"删除下载文件夹%@成功",fileStructure.downloadFolder.path);
                    }
                    
                    NSError *error;
                    //删除旧的www目录
                    if([fm fileExistsAtPath:fileStructure.wwwFolder.path]){
                        [fm removeItemAtPath:fileStructure.wwwFolder.path error:nil];
                    }
                    [SSZipArchive createZipFileAtPath:[fileStructure.baseFolder.path stringByAppendingPathComponent:@"www.zip"] withContentsOfDirectory:fileStructure.lastestWWWFolder.path];
                    [SSZipArchive unzipFileAtPath:[fileStructure.baseFolder.path stringByAppendingPathComponent:@"www.zip"] toDestination:[fileStructure.baseFolder.path   stringByAppendingPathComponent:@"www"]];
                    if([fm fileExistsAtPath:[fileStructure.baseFolder.path stringByAppendingPathComponent:@"www.zip"]]){
                        [fm removeItemAtPath:[fileStructure.baseFolder.path stringByAppendingPathComponent:@"www.zip"] error:nil];
                    }
                    //删除下载目录(日期形式的)
                    NSURL *newReleaseWWWFolder = [fileStructure.baseFolder URLByAppendingPathComponent:newAppConfig.contentConfig.releaseVersion isDirectory:YES];
                    if([fm fileExistsAtPath:newReleaseWWWFolder.path]){
                        [fm removeItemAtPath:newReleaseWWWFolder.path error:nil];
                    }
                   
                    // 3.保存新版本的启动地址
                    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                    [user setObject:fileStructure.lastestWWWFolder.path forKey:fileStructure.appName];
                    [user synchronize];
                }
            }
            // 保存配置文件
            [_appConfigStorage store:newAppConfig inFolder:fileStructure.lastestWWWFolder];
            [_manifestStorage store:newManifest inFolder:fileStructure.lastestWWWFolder];
        }
    }];
}

//移动文件
- (void)moveFileFromURL:(NSURL *)fromURL toPath:(NSURL *)toURL {
    NSError *error = nil;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:fromURL.path] && [fileManager fileExistsAtPath:toURL.path]) {
        [fileManager moveItemAtURL:fromURL toURL:toURL error:&error];
    }
    if(error) {
        NSLog(@"移动文件%@到%@出错",fromURL.path,toURL.path);
    }
}

//删除文件
- (BOOL)deleteFileWithPath:(NSString *)filePath {
    NSFileManager *manager = [NSFileManager defaultManager];
    if([manager fileExistsAtPath:filePath]) {
        //删除
        return [manager removeItemAtPath:filePath error:nil];
    } else {
        return false;
    }
}

// 删除已经下载的文件
- (void)deleteFileInNewWWWFolder:(NSArray *)deleteFiles
{
    for (HCPManifestFile *file in deleteFiles) {
        if(![self deleteFileWithPath:[fileStructure.lastestWWWFolder URLByAppendingPathComponent:file.name].path]) {
            NSLog(@"文件%@删除失败",file.name);
        }
    }
}



//拷贝旧版本www目录文件到新版本www目录下
- (BOOL)copyWWWFolderFromOldToNewWithConfig:(HCPApplicationConfig *)newAppConfig
{
    BOOL result = false;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // 1.创建新版本文件夹
    NSURL *newReleaseWWWFolder = [fileStructure.baseFolder URLByAppendingPathComponent:newAppConfig.contentConfig.releaseVersion isDirectory:YES];
    //如果存在先删除
    if([fileManager fileExistsAtPath:newReleaseWWWFolder.path]) {
        NSError *error;
        [fileManager removeItemAtPath:newReleaseWWWFolder.path error:&error];
        if(error){
            NSLog(@"删除微应用%@新版本文件夹出错:%@",fileStructure.appName,error);
        }
    }
    
    if(![fileManager createDirectoryAtPath:newReleaseWWWFolder.path withIntermediateDirectories:YES attributes:nil error:nil]) {
        NSLog(@"创建文件%@失败",newReleaseWWWFolder);
        result = false;
    }
    
    // 2.记录新的www文件地址
    fileStructure.lastestWWWFolder = [newReleaseWWWFolder URLByAppendingPathComponent:@"www"];
    
    // 3.移动文件
    // 3.1.在项目目录下创建一个www.zip文件
    NSString *path = [newReleaseWWWFolder.path stringByAppendingPathComponent:@"www.zip"];
    // 判断之前版本的www目录是否存在
    if(![fileManager fileExistsAtPath:fileStructure.wwwFolder.path]){
        NSLog(@"微应用%@不存在前端代码",fileStructure.appName);
        return false;
    }
    if([SSZipArchive createZipFileAtPath:path withContentsOfDirectory:fileStructure.wwwFolder.path]) {
        // 3.2.www.zip解压缩
        if([SSZipArchive unzipFileAtPath:path toDestination:[newReleaseWWWFolder.path stringByAppendingPathComponent:@"www"]]) {
            // 3.3.删除www.zip
            if([fileManager removeItemAtPath:path error:nil]) {
                result = true;
            }
        }
    }
    return result;
}

//创建下载文件夹
- (void)createNewReleaseDownloadFolder:(NSURL *)downloadFolder
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:downloadFolder.path]) {
        [fileManager removeItemAtURL:downloadFolder error:nil];
    }
    if(![fileManager createDirectoryAtPath:downloadFolder.path withIntermediateDirectories:YES attributes:nil error:nil]) {
        NSLog(@"创建下载文件夹%@失败",downloadFolder.path);
    }
}

- (HCPApplicationConfig *)getApplicationConfigFromData:(NSData *)data error:(NSError **)error {
    if (*error) {
        return nil;
    }
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:error];
    if (*error) {
        return nil;
    }
    
    return [HCPApplicationConfig instanceFromJsonObject:json];
}

- (HCPContentManifest *)getManifestConfigFromData:(NSData *)data error:(NSError **)error {
    if (*error) {
        return nil;
    }
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:error];
    if (*error) {
        return nil;
    }
    
    return [HCPContentManifest instanceFromJsonObject:json];
}

/**
 *  Load configuration files from the file system.
 *
 *  @param error object to fill with error data if something will go wrong
 *
 *  @return <code>YES</code> if configs are loaded; <code>NO</code> - if some of the configs not found on file system
 */
- (BOOL)loadLocalConfigs:(NSError **)error {
    //*error = nil;
    
    NSString *path = @"file://";
    path = [path stringByAppendingString:fileStructure.wwwFolder.path];
    _oldAppConfig = [_appConfigStorage loadFromFolder:[NSURL URLWithString:path]];
    if (_oldAppConfig == nil) {
        return NO;
    }
    
    _oldManifest = [_manifestStorage loadFromFolder:[NSURL URLWithString:path]];
    
    if (_oldManifest == nil) {
        
        return NO;
    }
    
    return YES;
}

@end
