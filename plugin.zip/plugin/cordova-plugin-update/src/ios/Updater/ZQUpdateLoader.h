//
//  ZQUpdateLoader.h
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import <Foundation/Foundation.h>

@class HCPUpdateRequest;

@interface ZQUpdateLoader : NSObject

- (BOOL)executeDownloadRequest:(HCPUpdateRequest *)request appName:(NSString*)appName error:(NSError **)error;

@end
