//
//  ZQUpdateLoaderWorker.h
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import <Foundation/Foundation.h>

@class HCPUpdateRequest;

@interface ZQUpdateLoaderWorker : NSObject

//属性
@property (nonatomic, strong) NSString *baseUrl;

- (instancetype)initWithRequest:(HCPUpdateRequest *)request appName:(NSString *)appName;
- (void)runWithComplitionBlock:(void (^)(NSError *error))updateLoaderComplitionBlock;

@end
