//
//  ZQFetchUpdate.h
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import <Foundation/Foundation.h>

@interface ZQFetchUpdate : NSObject

//------方法

- (BOOL)getNewVersionWithURL:(NSURL *)path;//获取新版本

- (void)fetchUpdateWithUrl:(NSString *)url appName:(NSString *)appName;//下载最新文件

@end
