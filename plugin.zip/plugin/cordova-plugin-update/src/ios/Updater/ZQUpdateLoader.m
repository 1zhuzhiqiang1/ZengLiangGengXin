//
//  ZQUpdateLoader.m
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import "ZQUpdateLoader.h"
#import "ZQUpdateLoaderWorker.h"
#import "HCPUpdateRequest.h"

@implementation ZQUpdateLoader

- (BOOL)executeDownloadRequest:(HCPUpdateRequest *)request appName:(NSString*)appName error:(NSError *__autoreleasing *)error
{
    ZQUpdateLoaderWorker* task = [[ZQUpdateLoaderWorker alloc] initWithRequest:request appName:appName];
    [task runWithComplitionBlock:^(NSError *error) {
        if(error) {
            
        } else {
            
        }
    }];
    return true;
}

@end
