//
//  ZQFetchUpdate.m
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import "ZQFetchUpdate.h"
#import "ZQUpdateLoader.h"
#import "HCPUpdateRequest.h"

@implementation ZQFetchUpdate


- (BOOL)getNewVersionWithURL:(NSURL *)path
{
    return true;
}

//url : 服务器端的plist文件的地址
//version : 本地的版本号
- (void)fetchUpdateWithUrl:(NSString *)url appName:(NSString *)appName
{
    HCPUpdateRequest *request = [[HCPUpdateRequest alloc] init];
    request.configURL = [NSURL URLWithString:url];
    
    ZQUpdateLoader *loader = [[ZQUpdateLoader alloc] init];
    NSError *error = nil;
    
    [loader executeDownloadRequest:request appName:appName error:&error];
    if(error) {
        
    }
    
}

@end
