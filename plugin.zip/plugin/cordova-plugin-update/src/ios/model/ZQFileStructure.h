//
//  ZQFileStructure.h
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import <Foundation/Foundation.h>
//#import "HCPFilesStructure.h"

@interface ZQFileStructure : NSObject

//------属性-------

@property (nonatomic, strong) NSURL *baseFolder;
@property (nonatomic, strong) NSURL *wwwFolder;
@property (nonatomic, strong) NSURL *lastestWWWFolder;
@property (nonatomic, strong) NSURL *downloadFolder;
@property (nonatomic, strong) NSString *appName;
@property (nonatomic, strong) NSString *webVersion;
@property (nonatomic, strong) NSString *configFileName;
@property (nonatomic, strong) NSString *manifestFileName;


//------方法------
- (instancetype)initWithAppName:(NSString *)appName webVersion:(NSString *)version;

@end
