//
//  ZQFileStructure.m
//  HyzmGjj
//
//  Created by anyware on 17/2/17.
//
//

#import "ZQFileStructure.h"

#define AppBasePath [[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"Anyware"] stringByAppendingPathComponent:@"microApplication"]

@implementation ZQFileStructure

- (instancetype)initWithAppName:(NSString *)appName webVersion:(NSString *)version
{
    if(self) {
        self.appName = appName;
        self.webVersion = version;
    }
    return self;
}

- (NSURL *)baseFolder
{
    if(_baseFolder == nil) {
        NSString *path = [AppBasePath stringByAppendingPathComponent:_appName];
        _baseFolder = [NSURL URLWithString:path];
        NSLog(@"微应用%@的目录地址是：%@",self.appName,path);
    }
    return _baseFolder;
}

- (NSURL *)wwwFolder
{
    if(_wwwFolder == nil){
        NSString *path = [AppBasePath stringByAppendingPathComponent:self.appName];
        path = [path stringByAppendingPathComponent:@"www"];
        _wwwFolder = [NSURL URLWithString:path];
    }
    return _wwwFolder;
}

- (NSURL *)downloadFolder
{
    if(_downloadFolder == nil) {
        _downloadFolder = [self.baseFolder URLByAppendingPathComponent:@"update"];
    }
    return _downloadFolder;
}

- (NSString *)configFileName {
    return @"chcp.json";
}

- (NSString *)manifestFileName {
    return @"chcp.manifest";
}

@end
