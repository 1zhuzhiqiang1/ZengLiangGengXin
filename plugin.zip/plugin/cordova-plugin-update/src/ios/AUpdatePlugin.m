/********* AUpdatePlugin.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>
#import "ZQFetchUpdate.h"
#import "ZQFileDownloader.h"
#import "SSZipArchive.h"

#define AppBasePath [[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"Anyware"] stringByAppendingPathComponent:@"microApplication"]

@interface AUpdatePlugin : CDVPlugin {
  // Member variables go here.
}

- (void)coolMethod:(CDVInvokedUrlCommand*)command;
- (void)downloadUpdate:(CDVInvokedUrlCommand*)command;
- (void)downloadWwwFolder:(CDVInvokedUrlCommand*)command;

@end

@implementation AUpdatePlugin

- (void)coolMethod:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult* pluginResult = nil;
    NSString* echo = [command.arguments objectAtIndex:0];

    if (echo != nil && [echo length] > 0) {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:echo];
    } else {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR];
    }

    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)downloadUpdate:(CDVInvokedUrlCommand*)command
{
    NSString *serverAddress = [command.arguments objectAtIndex:0];
    NSString *appName = [command.arguments objectAtIndex:1];
    NSLog(@"服务器地址：%@",serverAddress);

    ZQFetchUpdate *update = [[ZQFetchUpdate alloc] init];
    [update fetchUpdateWithUrl:serverAddress appName:appName];
}

- (void)downloadWwwFolder:(CDVInvokedUrlCommand*)command
{
    NSString *serverPath = [command.arguments objectAtIndex:0];
    NSString *appName = [command.arguments objectAtIndex:1];
    NSString *applicationFolder = [AppBasePath stringByAppendingPathComponent:appName];
    NSFileManager *fm = [NSFileManager defaultManager];
    if(![fm fileExistsAtPath:applicationFolder]){
        [fm createDirectoryAtPath:applicationFolder withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSLog(@"微应用%@地址--%@",appName,applicationFolder);
    serverPath = [serverPath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL* srcUrl = [NSURL URLWithString:serverPath];

    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        ZQFileDownloader* downloadTask = [[ZQFileDownloader alloc] initWithSrcUrl:srcUrl toFolderPath:applicationFolder requestHeaders:nil viewController:self.viewController];
        [downloadTask startDownloadWithCompletionBlock:^(NSError *error) {
            if(error) {
                NSLog(@"下载出错：%@",error);
            }else {
                NSLog(@"下载完成");
                //解压
                [SSZipArchive unzipFileAtPath:[applicationFolder stringByAppendingPathComponent:@"www.zip"] toDestination:applicationFolder];
                if([fm fileExistsAtPath:[applicationFolder stringByAppendingPathComponent:@"www.zip"]]){
                    [fm removeItemAtPath:[applicationFolder stringByAppendingPathComponent:@"www.zip"] error:nil];
                }
                if([fm fileExistsAtPath:[applicationFolder stringByAppendingPathComponent:@"__MACOSX"]]){
                    [fm removeItemAtPath:[applicationFolder stringByAppendingPathComponent:@"__MACOSX"] error:nil];
                }
            }
        }];
    });
}

@end
