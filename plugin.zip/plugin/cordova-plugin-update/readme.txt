本插件需要配合使用：
1、SSZipArchive 解压库
2、cordova-hot-code-push-plugin<修改版本的>